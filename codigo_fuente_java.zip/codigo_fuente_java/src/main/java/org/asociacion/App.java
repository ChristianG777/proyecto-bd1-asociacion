package org.asociacion;

public class App {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}

// Ejecutar primero el script SQL incluido.
// Configurar ruta, usuario y contraseña de PostgreSQL en la clase DB