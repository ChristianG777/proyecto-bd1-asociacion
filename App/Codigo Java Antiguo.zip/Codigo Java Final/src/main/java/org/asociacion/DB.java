package org.asociacion;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DB {

    private static final String URL = "jdbc:postgresql://localhost:5432/proyecto_bd1";
    private static final String USER = "postgres";
    private static final String PASS = "6354";

    static {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Connection get() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public static boolean insertarMiembro(Miembro m) {

        String sql = "INSERT INTO Miembro(idMiembro, nombres, apellidos, cedula, telefono, direccion, fechaIngreso, estado) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection c = get(); PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, m.id);
            ps.setString(2, m.nombres);
            ps.setString(3, m.apellidos);

            if (m.cedula == null) ps.setNull(4, Types.VARCHAR);
            else ps.setString(4, m.cedula);

            if (m.telefono == null) ps.setNull(5, Types.VARCHAR);
            else ps.setString(5, m.telefono);

            ps.setString(6, m.direccion);
            ps.setDate(7, java.sql.Date.valueOf(m.fechaIngreso));
            ps.setString(8, m.estado);

            ps.executeUpdate();
            return true;

        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public static Miembro buscarMiembroPorCedula(String cedula) {

        String sql = "SELECT * FROM Miembro WHERE cedula = ?";

        try (Connection c = get(); PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, cedula);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Miembro(
                            rs.getString("idMiembro"),
                            rs.getString("nombres"),
                            rs.getString("apellidos"),
                            rs.getString("cedula"),
                            rs.getString("telefono"),
                            rs.getString("direccion"),
                            rs.getDate("fechaIngreso") == null ? null : rs.getDate("fechaIngreso").toLocalDate(),
                            rs.getString("estado")
                    );
                }
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return null;
    }

    public static String crearMembresia(String idMiembro, String tipo, double costo, LocalDate inicio, LocalDate fin) {

        String idM = IDGenerator.generarID("MBR");

        String sql = "INSERT INTO Membresia(idMembresia, idMiembro, tipo, costo, fechaInicio, fechaFin, estado) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection c = get(); PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, idM);
            ps.setString(2, idMiembro);
            ps.setString(3, tipo);
            ps.setDouble(4, costo);
            ps.setDate(5, java.sql.Date.valueOf(inicio));
            ps.setDate(6, java.sql.Date.valueOf(fin));
            ps.setString(7, "ACTIVA");

            ps.executeUpdate();
            return idM;

        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public static boolean registrarPago(String idMembresia, double monto, String metodo) {

        String idPago = IDGenerator.generarID("PAY");

        String sql = "INSERT INTO PagoMembresia(idPago, idMembresia, fechaPago, monto, metodo) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (Connection c = get(); PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, idPago);
            ps.setString(2, idMembresia);
            ps.setDate(3, java.sql.Date.valueOf(LocalDate.now()));
            ps.setDouble(4, monto);
            ps.setString(5, metodo);

            ps.executeUpdate();
            return true;

        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public static boolean registrarPagoCompletoPorCedula(String cedula, String tipoMembresia, double costo, String metodo) {

        Miembro m = buscarMiembroPorCedula(cedula);
        if (m == null) return false;

        LocalDate inicio = LocalDate.now();
        LocalDate fin = inicio.plusYears(1);

        String idM = crearMembresia(m.id, tipoMembresia, costo, inicio, fin);
        if (idM == null) return false;

        return registrarPago(idM, costo, metodo);
    }

    public static List<String[]> reporte(LocalDate desde, LocalDate hasta, String beneficio) {

        List<String[]> lista = new ArrayList<>();

        String sql =
                "SELECT idMiembro, nombres, apellidos, fecha, beneficio FROM ( " +

                        " SELECT m.idMiembro, m.nombres, m.apellidos, ic.fechaInscripcion AS fecha, 'CAPACITACION' AS beneficio " +
                        " FROM InscripcionCapacitacion ic " +
                        " JOIN Miembro m ON ic.idMiembro = m.idMiembro " +
                        " WHERE ic.fechaInscripcion BETWEEN ? AND ? " +

                        " UNION " +

                        " SELECT mm.idMiembro, mm.nombres, mm.apellidos, mi.fechaEntrega AS fecha, 'INSUMO' AS beneficio " +
                        " FROM MembresiaInsumo mi " +
                        " JOIN Membresia mb ON mi.idMembresia = mb.idMembresia " +
                        " JOIN Miembro mm ON mb.idMiembro = mm.idMiembro " +
                        " WHERE mi.fechaEntrega BETWEEN ? AND ? " +

                        " UNION " +

                        " SELECT m2.idMiembro, m2.nombres, m2.apellidos, mb2.fechaInicio AS fecha, 'MEMBRESIA' AS beneficio " +
                        " FROM Membresia mb2 " +
                        " JOIN Miembro m2 ON mb2.idMiembro = m2.idMiembro " +
                        " WHERE mb2.fechaInicio BETWEEN ? AND ? " +

                        " UNION " +

                        " SELECT m3.idMiembro, m3.nombres, m3.apellidos, rm.fechaInicio AS fecha, 'MAQUINARIA' AS beneficio " +
                        " FROM ReservaMaquinaria rm " +
                        " JOIN Miembro m3 ON rm.idMiembro = m3.idMiembro " +
                        " WHERE rm.fechaInicio BETWEEN ? AND ? " +

                        ") q";

        try (Connection c = get(); PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setDate(1, java.sql.Date.valueOf(desde));
            ps.setDate(2, java.sql.Date.valueOf(hasta));

            ps.setDate(3, java.sql.Date.valueOf(desde));
            ps.setDate(4, java.sql.Date.valueOf(hasta));

            ps.setDate(5, java.sql.Date.valueOf(desde));
            ps.setDate(6, java.sql.Date.valueOf(hasta));

            ps.setDate(7, java.sql.Date.valueOf(desde));
            ps.setDate(8, java.sql.Date.valueOf(hasta));

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new String[]{
                            rs.getString("idMiembro"),
                            rs.getString("nombres"),
                            rs.getString("apellidos"),
                            rs.getDate("fecha") == null ? "" : rs.getDate("fecha").toString(),
                            rs.getString("beneficio")
                    });
                }
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        if (!beneficio.equalsIgnoreCase("TODOS")) {
            List<String[]> filtrado = new ArrayList<>();
            for (String[] r : lista) {
                if (r[4].equalsIgnoreCase(beneficio))
                    filtrado.add(r);
            }
            return filtrado;
        }

        return lista;
    }

    public static List<String[]> obtenerContratosPorMonto(double monto, String comparacion) {
        List<String[]> lista = new ArrayList<>();
        String operador;

        switch (comparacion) {
            case "MAYOR_O_IGUAL":
                operador = ">= ?";
                break;
            case "MENOR_O_IGUAL":
                operador = "<= ?";
                break;
            case "EXACTO":
                operador = "= ?";
                break;
            default:
                return lista;
        }

        String sql =
                "SELECT ee.nombre AS nombreEntidad, " +
                        "       c.fechaInicio, " +
                        "       c.fechaFin, " +
                        "       c.monto " +
                        "FROM Contrato c " +
                        "JOIN EntidadExterna ee ON c.idEntidadExterna = ee.idEntidadExterna " +
                        "WHERE c.monto " + operador;

        try (Connection c = get(); PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setDouble(1, monto);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new String[]{
                            rs.getString("nombreEntidad"),
                            rs.getDate("fechaInicio") == null ? "" : rs.getDate("fechaInicio").toString(),
                            rs.getDate("fechaFin") == null ? "" : rs.getDate("fechaFin").toString(),
                            String.format("%.2f", rs.getDouble("monto"))
                    });
                }
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return lista;
    }
}