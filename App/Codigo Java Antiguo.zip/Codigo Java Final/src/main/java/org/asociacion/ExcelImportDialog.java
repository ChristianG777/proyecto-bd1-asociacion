package org.asociacion;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class ExcelImportDialog extends JDialog {

    public ExcelImportDialog(Frame owner) {
        super(owner, "Importar Excel", true);

        setSize(400, 200);
        setLayout(new BorderLayout());
        setLocationRelativeTo(owner);

        JLabel label = new JLabel("Seleccione un archivo Excel (.xlsx) con las hojas por tabla", SwingConstants.CENTER);

        JButton btnSeleccionar = new JButton("Seleccionar archivo...");
        btnSeleccionar.addActionListener(e -> seleccionarArchivo());

        add(label, BorderLayout.NORTH);
        add(btnSeleccionar, BorderLayout.CENTER);
    }

    private void seleccionarArchivo() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Seleccionar archivo Excel");

        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File f = chooser.getSelectedFile();

            try {
                ExcelImporter.importExcel(f);
                JOptionPane.showMessageDialog(this,
                        "Importación completada con éxito.",
                        "Éxito",
                        JOptionPane.INFORMATION_MESSAGE);

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        "Error durante la importación:\n" + ex.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}