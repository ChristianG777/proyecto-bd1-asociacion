package org.asociacion;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;

public class ExcelImporter {

    private static final String URL = "jdbc:postgresql://localhost:5432/proyecto_bd1";
    private static final String USER = "postgres";
    private static final String PASS = "6354";

    // Orden recomendado para respetar FKs
    private static final String[] TABLE_ORDER = new String[]{
            "miembro",
            "proveedor",
            "cultivo",
            "maquinaria",
            "capacitacion",
            "entidadexterna",
            "mandato",
            "producto",
            "insumo",
            "membresia",
            "contrato",
            "convenio",
            "venta",
            "cargo",
            "miembrocultivo",
            "inscripcioncapacitacion",
            "reservamaquinaria",
            "detallesmembresia",
            "membresiainsumo",
            "pagomembresia",
            "pago",
            "gasto",
            "detalleventa"
    };

    public static void importExcel(File xlsxFile) throws Exception {
        try (Connection conn = getConnection()) {

            conn.setAutoCommit(false);

            Map<String, List<Map<String, Object>>> data = readWorkbook(xlsxFile);

            for (String table : TABLE_ORDER) {

                if (!data.containsKey(table)) {
                    System.out.println("Hoja no encontrada: " + table + " (saltada)");
                    continue;
                }

                List<Map<String, Object>> rows = data.get(table);
                if (rows.isEmpty()) continue;

                System.out.println("Importando " + table + " (" + rows.size() + " filas)...");

                importTable(conn, table, rows);

                conn.commit();
                System.out.println("✓ Tabla " + table + " importada.");
            }
        }
    }

    private static Connection getConnection() throws SQLException {
        try { Class.forName("org.postgresql.Driver"); }
        catch (Exception ignored) {}
        return DriverManager.getConnection(URL, USER, PASS);
    }

    private static Map<String, List<Map<String, Object>>> readWorkbook(File f) throws Exception {
        Map<String, List<Map<String, Object>>> result = new HashMap<>();

        try (FileInputStream fis = new FileInputStream(f);
             Workbook wb = new XSSFWorkbook(fis)) {

            for (int s = 0; s < wb.getNumberOfSheets(); s++) {

                Sheet sheet = wb.getSheetAt(s);
                String name = sheet.getSheetName().trim().toLowerCase();

                Iterator<Row> it = sheet.rowIterator();
                if (!it.hasNext()) continue;

                Row header = it.next();
                List<String> cols = new ArrayList<>();

                for (Cell cell : header) {
                    String h = cell.getStringCellValue().trim().toLowerCase();
                    cols.add(h);
                }

                List<Map<String, Object>> rows = new ArrayList<>();

                while (it.hasNext()) {
                    Row r = it.next();
                    Map<String, Object> map = new LinkedHashMap<>();

                    for (int i = 0; i < cols.size(); i++) {
                        Cell cell = r.getCell(i);
                        Object val = readCellValue(cell);
                        map.put(cols.get(i), val);
                    }
                    rows.add(map);
                }

                result.put(name, rows);
            }
        }

        return result;
    }

    private static Object readCellValue(Cell cell) {
        if (cell == null) return null;

        switch (cell.getCellType()) {

            case STRING:
                String s = cell.getStringCellValue().trim();
                return s.isEmpty() ? null : s;

            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    java.util.Date d = cell.getDateCellValue();
                    return new java.sql.Date(d.getTime()).toLocalDate();
                }
                return cell.getNumericCellValue();

            case BOOLEAN:
                return cell.getBooleanCellValue();

            default:
                return null;
        }
    }

    private static void importTable(Connection conn, String tableName, List<Map<String, Object>> rows) throws SQLException {

        Map<String, String> columnTypes = getColumnTypes(conn, tableName);
        List<String> pkCols = getPrimaryKeyColumns(conn, tableName);

        for (Map<String, Object> row : rows) {

            List<String> cols = new ArrayList<>();
            List<Object> vals = new ArrayList<>();

            for (String col : row.keySet()) {

                if (!columnTypes.containsKey(col)) continue;

                Object converted = convertValue(row.get(col), columnTypes.get(col));
                cols.add(col);
                vals.add(converted);
            }

            if (cols.isEmpty()) continue;

            boolean exists = checkDuplicate(conn, tableName, cols, vals, pkCols);

            if (exists) continue;

            insertRow(conn, tableName, cols, vals);
        }
    }


    private static void insertRow(Connection conn, String table, List<String> cols, List<Object> vals)
            throws SQLException {

        String colList = String.join(", ", cols);
        String placeholders = String.join(", ", Collections.nCopies(cols.size(), "?"));

        String sql = "INSERT INTO " + table + " (" + colList + ") VALUES (" + placeholders + ")";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            for (int i = 0; i < vals.size(); i++) {
                Object v = vals.get(i);

                if (v == null) {
                    ps.setNull(i + 1, Types.NULL);
                }
                else if (v instanceof java.sql.Date) {
                    ps.setDate(i + 1, (java.sql.Date) v);
                }
                else if (v instanceof LocalDate) {
                    ps.setDate(i + 1, java.sql.Date.valueOf((LocalDate) v));
                }
                else if (v instanceof Double) {
                    ps.setDouble(i + 1, (Double) v);
                }
                else if (v instanceof Number) {
                    ps.setLong(i + 1, ((Number) v).longValue());
                }
                else {
                    ps.setString(i + 1, v.toString());
                }
            }

            ps.executeUpdate();
        }
        catch (SQLException ex) {
            System.err.println("❌ Error insertando en tabla " + table + ": " + ex.getMessage());
        }
    }

    private static boolean checkDuplicate(Connection conn, String table, List<String> cols,
                                          List<Object> vals, List<String> pkCols) throws SQLException {

        if (pkCols.isEmpty()) return false;

        for (String pk : pkCols)
            if (!cols.contains(pk)) return false;

        StringBuilder sql = new StringBuilder("SELECT 1 FROM " + table + " WHERE ");
        List<Object> pkVals = new ArrayList<>();

        for (int i = 0; i < pkCols.size(); i++) {
            if (i > 0) sql.append(" AND ");
            sql.append(pkCols.get(i)).append(" = ?");
            pkVals.add(vals.get(cols.indexOf(pkCols.get(i))));
        }

        try (PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < pkVals.size(); i++) {
                Object v = pkVals.get(i);
                if (v == null) ps.setNull(i + 1, Types.NULL);
                else if (v instanceof Long) ps.setLong(i + 1, (Long) v);
                else ps.setObject(i + 1, v);
            }
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    private static Map<String, String> getColumnTypes(Connection conn, String table) throws SQLException {

        String sql =
                "SELECT column_name, data_type " +
                        "FROM information_schema.columns " +
                        "WHERE table_name = ? AND table_schema='public'";

        Map<String, String> out = new HashMap<>();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, table);   // tabla ya en minúsculas
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.put(rs.getString("column_name"), rs.getString("data_type"));
                }
            }
        }
        return out;
    }

    private static List<String> getPrimaryKeyColumns(Connection conn, String table) throws SQLException {

        List<String> pk = new ArrayList<>();

        String sql =
                "SELECT a.attname " +
                        "FROM pg_index i " +
                        "JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey) " +
                        "WHERE i.indrelid = ?::regclass AND i.indisprimary";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, table);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) pk.add(rs.getString("attname"));
            }
        }
        return pk;
    }

    private static Object convertValue(Object val, String type) {

        if (val == null) return null;

        String t = type.toLowerCase();

        try {

            if (t.contains("date")) {
                if (val instanceof LocalDate) return java.sql.Date.valueOf((LocalDate) val);

                String s = val.toString().replace("/", "-");
                return java.sql.Date.valueOf(LocalDate.parse(s));
            }

            if (t.contains("decimal") || t.contains("numeric")) {
                return Double.parseDouble(val.toString());
            }

            if (t.contains("int") || t.contains("bigint")) {
                Double d = Double.parseDouble(val.toString());
                return d.longValue();
            }

            if (t.contains("char") || t.contains("text")) {
                return val.toString();
            }

        } catch (Exception ignored) {}

        return val.toString();
    }
}